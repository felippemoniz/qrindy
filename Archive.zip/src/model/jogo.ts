export class jogo{
  constructor(
    public idJogo?:number,
    public nomeJogo?:string,
    public qtPistas?:number,
    public mensagemTesouro?:string
  )
  {}
}
