import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { CriarJogo } from '../criarjogo/criarjogo';
import { DetalharJogo } from '../detalharJogo/detalharJogo';
import { DbProvider } from '../../providers/db/db';
import { LoadingController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  public listaJogos;
  public qtJogos=0;


  constructor(public navCtrl: NavController,
              public loadingCtrl: LoadingController = null,
              public dbProvider: DbProvider) {

              this.carregarListaJogos();

  }


  criarJogo(){
    this.navCtrl.push(CriarJogo)
  }


  detalharJogo(idJogo){
    this.navCtrl.push(DetalharJogo,{idJogo: idJogo});
  }


  ionViewDidEnter(){
    this.carregarListaJogos();
  }


  carregarListaJogos(){

    let loading = this.loadingCtrl.create({
      spinner: 'ios',
      content: 'Carregando o jogo...'
    });

    loading.present();

    this.dbProvider.initDB("","7");
    this.dbProvider.executeSql("select tbJogo.*, count(tbPista.id_pista)  qtPistas from " +
                              "tb_jogo tbJogo " +
                              "left join  tb_Pista tbPista " +
                              "on tbJogo.id_jogo = tbPista.id_jogo " +
                              "group by tbJogo.id_jogo order by tbJogo.id_jogo desc").then( obj  => {
    this.listaJogos=obj;
    loading.dismiss();
    //this.qtJogos=obj.length;

    }, () => {
      console.log("Erro")
      loading.dismiss();
    });
  }


}
